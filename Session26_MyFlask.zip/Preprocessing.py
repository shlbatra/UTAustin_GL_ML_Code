import re, string, unicodedata                          # Import Regex, string and unicodedata.

import numpy as np                                      # Import numpy.
import pandas as pd                                     # Import pandas.
import nltk                                             # Import Natural Language Tool-Kit.



from nltk.tokenize import word_tokenize, sent_tokenize  # Import Tokenizer.
from nltk.stem.wordnet import WordNetLemmatizer         # Import Lemmatizer.

lemmatizer = WordNetLemmatizer()

try:
    nltk.download('punkt', download_dir='/opt/python/current/app')
except:
    nltk.download('punkt')

try:
    nltk.download('wordnet', download_dir='/opt/python/current/app')
except:
    nltk.download('wordnet')

def tokenize(row):
    words = nltk.word_tokenize(row)
    return words

def remove_non_ascii(words):
    """Remove non-ASCII characters from list of tokenized words"""
    new_words = []
    for word in words:
        new_word = unicodedata.normalize('NFKD', word).encode('ascii', 'ignore').decode('utf-8', 'ignore')
        new_words.append(new_word)
    return new_words

def to_lowercase(words):
    """Convert all characters to lowercase from list of tokenized words"""
    new_words = []
    for word in words:
        new_word = word.lower()
        new_words.append(new_word)
    return new_words

def lemmatize_list(words):
    new_words = []
    for word in words:
      new_words.append(lemmatizer.lemmatize(word, pos='v'))
    return new_words

def normalize(row):
    words = tokenize(row)
    words = remove_non_ascii(words)
    words = to_lowercase(words)
    return ' '.join(words)
