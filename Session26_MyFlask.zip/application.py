from flask import Flask,request
import joblib
from sklearn.pipeline import Pipeline
from Preprocessing import normalize


application = Flask(__name__)

vectorizer = joblib.load("vectorizer.pkl")
model = joblib.load("forest_model.pkl")

@application.route('/')
def hello_word():
    return "Hello World"

@application.route('/sentiment',methods=['GET','POST'])

def predict_sentiment():
    tweet = request.args.get("tweet")
    tweet = normalize(tweet)
    vect_message = vectorizer.transform([tweet])
    result = model.predict(vect_message)[0]
    return result

if __name__ == '__main__':
    application.run()


